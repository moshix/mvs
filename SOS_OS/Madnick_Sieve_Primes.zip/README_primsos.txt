Sieve Of Eratosthenes For The Sample Operating System Version 2.00
==================================================================

The book "Operating Systems" by Stuart E. Madnick and John J. Donovan
(McGraw-Hill 1974) describes a sample operating system suitable to run on
IBM S/360 and S/370 computers.

This zip archive contains an implementation of the well known Sieve of
Eratosthenes prime number algorithm suitable to run on the sample operating
system. On a 16 MB machine it can compute all primes less than 268,154,112.


Contents:
---------

README_primsos.txt - this file
rdr/P2000N.card    \ 
rdr/P2000Y.card     \   
rdr/P268154112N.card >  sample control cards
rdr/P3000N.card     /   
rdr/P3000Y.card    /
rdr/Sieve_of_Eratosthenes.deck   - combined job card and object deck
source/Sieve_of_Eratosthenes.asm - assembler source of the sieve program

The sieve program is controlled by a card added after the object deck to the job
stream. This card is EBCDIC encoded and has the following format:

----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
 nnnnnnnnnp                                                                     

where:

nnnnnnnnn is the sieve limit, right justified: All primes below this limit are
          computed.

p         specifies whether the primes found shall be output on the printer
          assigned to the job stream: Y means "print primes", N means "don't
          print".

The zip archive contains a few sample control cards. The following naming
convention is used to identify them: The number starting after the P is the
sieve limit, the character following the number is the p value. So, for example,
file P3000Y.card specifies to compute all primes below 3000 and to print them.


Installation:
-------------

If not yet done, install the sample operating system using the following files
from the hercules-390 Yahoo group's file section:

Madnick_for_Hercules.zip
Madnick_4_KB_for_Hercules.zip
Madnick_4_KB_RDR_for_Hercules.zip

Unzip the zip archives in the above sequence into the same folder, allowing
the unzip utility in each step to overwrite files and merge folders already
existing. See the README files in the zip archives for details if necessary.

Then unzip archive Madnick_Sieve_Primes.zip into the folder used to install the
sample operating system, again allowing the unzip utility to overwrite files
and merge folders already existing.


Usage:
------

1. Start sample operating system:

   o make sure to have Hercules in your path
   o run start_herc (*i*x systems) or start_herc.bat (Windows systems)
   o enter "ipl c" at the Hercules console prompt

   The system will enter a wait state (PSW=FE0200008000056A) when it is
   ready to process jobs.

2. Submit Sieve of Eratosthenes job:

   o create a control card or choose one of the sample cards provided
   o enter "devinit c rdr/Sieve_of_Eratosthenes.deck <crd> eof ebcdic multifile"
     where <crd> is the pathname of the control card, relative to the folder
     from which Hercules was started.

   The system will process the job and enter a wait state (PSW=FE0200008000056A)
   upon completion.

3. Review job output:

   o enter "sh <cmd> prt/stream-2_output.txt"
     where <cmd> is "type" on Windows or "cat" on *i*x systems.

   The output will now be displayed on the Hercules console. Note that of course
   any other method of choice can be used to view the output file.


Modify the sieve program
------------------------

o edit and assemble source/Sieve_of_Eratosthenes.asm
o replace rdr/Sieve_of_Eratosthenes.deck with the new object deck


Have fun!


----------
8.11.2015, Juergen Winkelmann, ETH Zuerich
e-mail: winkelmann@id.ethz.ch
