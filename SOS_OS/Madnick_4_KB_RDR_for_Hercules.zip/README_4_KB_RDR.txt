Sample Operating System Version 2.00 - Card Reader Handling Enhancement
=======================================================================

The book "Operating Systems" by Stuart E. Madnick and John J. Donovan
(McGraw-Hill 1974) describes a sample operating system suitable to run on an
IBM S/360 computer.

In the files section of the hercules-390 Yahoo group an updated version was
published (Madnick_4_KB_for_Hercules.zip) to provide compatibility with the 4 KB
storage protection block size used on S/370 systems while keeping functionality
identical to the original version from the "Operating Systems" book. The present
enhancement is based on this updated version.

The "Operating Systems" book states in Chapter 7-14.1: "If there are no more
jobs to be run, the supervisor process will become blocked because it will try
to read input messages that it will never get." Although from this one cannot
clearly deduct what is supposed to happen when there arrive jobs to be processed
later on, one nowadays would assume the system to continue processing. However,
it doesn't: It remains sitting there with the supervisor blocked. The reason for
this is the reader process, not recognizing the attention interrupt raised by
Hercules once a new card deck has been placed in the reader using the devinit
command.

From an operations point of view this means that the system needs to be re-IPLed
to start processing new jobs once the readers ran dry after having processed
the jobs entered originally. While not being a big issue it's a bit cumbersome
to always remember adding the IPL deck in front of the user job decks into the
reader and to IPL to get things started.

The card reader enhancement solves this problem by restarting the card I/O upon
receiving an attention interrupt and ignoring the unit exception presented by
the reader when it ran dry. As a result jobs can be placed into the readers at
any time and the system will resume normal processing without needing to re-IPL.


Installation:
-------------

This is the second update applied to the original version of the sample
operating system. Updates need to be installed in sequence, so unzip

https://groups.yahoo.com/neo/groups/hercules-390/files/Madnick_for_Hercules.zip

first. Then unzip the 4K update archive

https://groups.yahoo.com/neo/groups/hercules-390/files/Madnick_4_KB_for_Hercules.zip

into the same folder, allowing the unzip program to replace files already 
existing, and finally unzip the card reader handling enhancement

https://groups.yahoo.com/neo/groups/hercules-390/files/Madnick_4_KB_RDR_for_Hercules.zip

into the same folder, again allowing the unzip program to replace files already
existing.


Contents:
---------

README_4_KB_RDR.txt - this file
hercules.rc         - Hercules initialization script
conf/madnick.cnf    - Hercules configuration file
rdr/sample_operating_system_version_2.00.ipldeck - card deck to IPL sample OS
scripts/load_card_decks - script to load demo user program card decks
source/sos4krdr.asm - updated sample OS source
sysgen/madnick_4_kb_blocks+reader_enhancement_update.xmi - XMITted PDS containing
                                                     source and build information

Note that rdr/sample_operating_system_version_2.00.ipldeck is identical to
member IPL4KRDR of the PDS contained in
sysgen/madnick_4_kb_blocks+reader_enhancement_update.xmi. Follow the instructions
in member $README of this PDS to rebuild the IPL deck from source.


Usage:
------

The following steps provide minimal information to IPL the sample operating
system and to run the demo user program from four card readers simultaneously:

o make sure to have Hercules in your path
o run start_herc (*i*x systems) or start_herc.bat (Windows systems)
o enter "script scripts/load_card_decks" at the Hercules console prompt
o enter "ipl c" at the Hercules console prompt
o the system will enter a wait state (PSW=FE0200008000056A) after completion
  of the four jobs
o review the output of the four jobs in folder prt
o to rerun, enter "script scripts/load_card_decks" at the Hercules console prompt



Have fun!

----------
05.11.2015, Juergen Winkelmann, ETH Zuerich
e-mail: winkelmann@id.ethz.ch
