Sieve of Eratosthenes Standalone Program for S/370
--------------------------------------------------

This is an S/370 standalone program to run the Sieve of Eratosthenes
algorithm. It computes all prime numbers below a given sieve limit. The
user will be prompted to enter the sieve limit and to specify whether to
print the prime numbers found. Prompting and, if selected, printing will
be done on the 3215 console printer keyboard at address 009.

The ZIP archive contains the following files:

README.txt   -- this file
prim370i     -- Hercules script to initiate the program using IPL
prim370l     -- Hercules script to initiate the program using LOADCORE
prim370.370  -- binary core image loadable using the Hercules LOADCORE command
prim370.deck -- card deck containing an IPLable loader followed by prim370.370
iplcard.asm  -- source code for the first card of prim370.deck (IPL card) (1)
cardldr.asm  -- source code for 2nd and 3rd card of prim370.deck (loader) (1)
prim370.asm  -- source code for the prim370.370 binary core image         (1)
prim370.cnf  -- Hercules configuration for use with the sieve program


Usage
-----

o Unzip the archive to an arbitrary folder.
o Open a command prompt (Windows) or a shell (non Windows) and change directory
  to the folder into which the archive was unzipped.
o Make sure hercules is in your path, then enter "hercules -f prim370.cnf".
o Attach a telnet session to local port 3215, for example by entering
  "telnet localhost 3215". Note that this has to be a regular telnet session,
  not tn3270.
o Enter "script prim370i" or "script prim370l" at the command prompt of the
  Hercules console to start the program. Both scripts start exactly the same
  program, they differ in the way the program is loaded into main storage
  and subsequently started only:
   - prim370i performs a classical IPL (Initial Program LOAD), which is a
     method that would work with a real machine too.
   - prim370l uses the LOADCORE command to load the program into main storage
     and the PSW command to set the initial PSW, which has no direct equivalent
     on a real machine (except entering the code manually at the control panel).
o Answer the prompts displayed in the telnet session (2).
o The numbers up to the limit entered will now be sieved for primes (3).
o After completion the number of primes found is displayed and a disabled wait
  state EC0815 is loaded.
o To rerun the program enter "script prim370i" or "script prim370l" on the
  Hercules console again.


Notes
-----

(1) The source is provided for documentation purposes primarily. Unless the 
    program is to be changed it is not necessary to assemble it, the binary
    files prim370.370 and prim370.deck fully match the source shipped. To
    assemble the source, a suitable assembler is needed (ASSEMBLER XF as
    provided with MVS 3.8j is known to work). The source contains brackets
    denoting the input defaults in source lines 308 and 310. Depending on the
    code page(s) in use those brackets might need fixing to rebuild from source:
    The EBCDIC repesentation of the source should use x'AD' for the left and
    x'BD' for the right bracket. Once assembled the resulting S/370 code must
    be extracted from the text section of the load modules and be transferred
    to the Hercules host.

(2) It is not recommended to have the primes printed for large sieve limits,
    as the 3215 console printer keyboard emulated through the telnet session
    is a slow device. The maximum usable sieve limit is 268398400.

(3) When running the program using large sieve limits it may take a few minutes
    to complete. During this time it may be of interest to observe the Hercules
    device and status panel, which can be obtained by pressing Esc on the
    Hercules console.


----------
Juergen Winkelmann, winkelmann@id.ethz.ch, 2014/12/07
