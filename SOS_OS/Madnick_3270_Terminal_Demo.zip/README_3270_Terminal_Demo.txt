Sample Operating System Version 2.00 - 3270 Terminal I/O Demo
=============================================================

The book "Operating Systems" by Stuart E. Madnick and John J. Donovan
(McGraw-Hill 1974) describes a sample operating system suitable to run on
IBM S/360 and S/370 computers.

While providing a programming interface for card readers and printers, the
sample operating system doesn't come with equivalent support for 3270 terminal
devices. It provides, however, an "EXCP Device Handler" allowing user programs
to execute channel programs addressing arbitrary devices, as long as UCBs for
these devices are defined in the UCB table. Thus, after adding "3270 UCBs"
to the UCB table and after adding matching 3270 devices to the hardware
(Hercules), user programs can perform 3270 I/O using the EXCP device handler.

Basically this is the same concept as was demonstrated in the Console I/O
package (see file Madnick_with_Console.zip in folder Sample_Operating_System
in the files section of the hercules-390 Yahoo group). The console I/O package,
however, has linemode consoles (IBM 1052 or IBM 3215) in mind, which operate
synchronously on read (read channel commands wait infinitely until data is
entered and sent by the operator). As opposed, 3270 devices, never wait on read
channel commands. Instead, they immediately return a data stream describing what
(if anything) has been done by the operator.

An implementation equivalent to the 1052/3215 would require to loop on read
channel commands until the desired reply is received, which isn't exactly
efficient, and which, in case of the sample operating system, would have a
massive performance impact, given that timed waits are not supported for user
processes.

However, a 3270 device delivers an attention interrupt when the user performs
an action defined to do so (ENTER, PF Keys, PA Keys, Lightpen). This allows to
wait for an attention interrupt to occur, instead of issuing consecutive reads
to the 3270 device. Once the attention interrupt occurs a single read suffices
to transfer all user actions (or even the whole device buffer, if so desired).

As provided with the sample operating system the EXCP device handler doesn't
support waiting for an unsolicited (attention) interrupt. The 3270 Terminal I/O
package contains a modified EXCP device handler which will wait for an interrupt
from the device without actually performing an I/O operation. This behavior is
activated by setting the high order bit of the CCW address in the EXCP parameter
list to one. That way a user program can easily select whether it just wants to
wait or whether it wants to perform normal EXCP processing.

The 3270 Terminal I/O package contains a demo program which displays a simple
panel with a single input field and requests the user to enter something.
The entered data is reflected back to the terminal and the input field is
cleared, waiting for the next entry. The CUU address of the 3270 device to use
is obtained from the first four bytes (one full word) of the card immediately
following the program's object object deck in the card reader the job was
submitted to. The version of the sample operating system provided with the
3270 Terminal I/O package has UCBs for addresses 009 and 01F defined, which
can be used for 3270 I/O. Control cards directing the demo program to select
one of these addresses are provided too.

This is meant as a proof of concept style example on using the EXCP device
handler only. In particular, I/O is not checked for completeness, success or
failure and unsolicited interrupts are not checked for being anything else than
attention, which certainly would need to be done for real world usability.


Installation:
-------------

Before installing the 3270 Terminal I/O package, please ensure you have the
sample operating system with the card reader handling enhancement installed,
as found and described in file Madnick_4_KB_RDR_for_Hercules.zip in folder
Sample_Operating_System in the files section of the hercules-390 Yahoo group.

It is recommended to install the Console I/O package on a separate copy of the
sample operating system, as it changes the Hercules configuration (hardware)
and the system configuration (device support). To install the package unzip
archive Madnick_3270_Terminal_Demo.zip (found in folder Sample_Operating_System
in the files section of the hercules-390 Yahoo group) into the folder containing
the copy of the sample operating system to be used, allowing the unzip program
to merge folders and replace files already existing.

It should be noted that the updated version of the sample operating system
is fully upward compatible with the other use cases published in folder
Sample_Operating_System in the files section of the hercules-390 Yahoo group
(demo user program with and without 3215 console, Sieve of Eratosthenes,
99 bottles of beer, etc.). It simply must be ensured that a matching Hercules
configuration is chosen and the correct card sequences ($JOB card, object deck,
control/data cards) are loaded into the card reader(s) and the consoles to be
used are ready before starting the respective programs.


Contents:
---------

README_3270_Terminal_Demo.txt - this file
conf/madnick.cnf              - Hercules configuration file
source/sos4krdg.asm           - sample operating system source, including UCBs
                                for devices 009 and 01F, and the EXCP handler
                                "wait for attention" support
source/t3270sos.asm           - 3270 demo user program source
rdr/sample_operating_system   - card deck to IPL sample OS
    _version_2.00.ipldeck
rdr/t3270sos.deck             - card deck to submit the 3270 demo program
rdr/terminal_009.card         - control card to make t3270sos use terminal 009
rdr/terminal_01f.card         - control card to make t3270sos use terminal 01F
sysgen/madnick_4_kb_blocks    - XMITted PDS containing source
       +reader_enhancement      and build information
       +EXCP_wait_support
       +UCBs_009&01F.xmi

Note that rdr/sample_operating_system_version_2.00.ipldeck is identical to
member IPL4KRDG of the PDS contained in sysgen/madnick_4_kb_blocks
+reader_enhancement+EXCP_wait_support+UCBs_009&01F.xmi. Follow the
instructions in member $README of this PDS to rebuild the IPL deck from source.


Usage:
------

The following steps provide minimal information to IPL the sample operating
system and to run the 3270 demo program:

o make sure to have Hercules in your path
o run start_herc (*i*x systems) or start_herc.bat (Windows systems)
o connect a tn3270 session to your local port 3270
o enter "ipl c" at the Hercules console prompt
o The system will enter a wait state (PSW=FE0200008000056A) when it is ready
  to process jobs
o enter "devinit c rdr/t3270sos.deck rdr/terminal_009.card ebcdic eof multifile"
  at the Hercules console prompt. The following panel will be displayed in the
  tn3270 session:
   ____________________________________________________________________________
  |                          "Operating Systems"                               |
  |                by Stuart E. Madnick and John J. Donovan                    |
  |                          (McGraw-Hill  1974)                               |
  |                                                                            |
  |                  Sample Operating System Version 2.00                      |
  |                                                                            |
  |--------------------- 3270 Console -- Test Program -------------------------|
  |                                                             Entry:   004000|
  |                                                             Console:    009|
  |                                                                            |
  |Enter something ==>                                                         |
  |                                                                            |
  |User entered:                                                               |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |                                                                            |
  |____________________________________________________________________________|

  Any data entered in the input field will be moved to the output field after
  pressing ENTER or a PF key. Pressing the CLEAR key will redisplay the initial
  state of the panel. Entering EXIT (case insensitive) will terminate the
  program.
o the system will enter a wait state (PSW=FE0200008000056A) while the 3270 demo
  program is waiting for input as well as after termination of the program.
o review the output of the job in file prt/stream-2_output.txt. It should
  contain the jobcard and the termination message only:

  $JOB,2K,READER=IN,CONSOLE=EXCP
  PROGRAM HALT

o to run the program again, simply re-enter the "devinit" command shown above.



Have fun!

----------
2015/11/28, Juergen Winkelmann, ETH Zuerich
e-mail: winkelmann@id.ethz.ch
