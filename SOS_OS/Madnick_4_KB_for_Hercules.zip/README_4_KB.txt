Sample Operating System Version 2.00 - 4K Update
================================================

The book "Operating Systems" by Stuart E. Madnick and John J. Donovan
(McGraw-Hill 1974) describes a sample operating system suitable to run on an
IBM S/360 computer. This zip archive contains a configuration for the Hercules
System/370, ESA/390, and z/Architecture Emulator to IPL the sample
operating system and to submit a demo user program job to four streams (card
readers).

This is an update of the version printed in the "Operating Systems" book. It is
functionally identical but has been updated to be runnable on S/370 systems with
4KB single or double key storage protection. See the comment header of the
source/sos4k.asm file for a complete list of changes.


Installation:
-------------

This is an update to the original version of the sample operating system, which
needs to be installed by unzipping the original archive

https://groups.yahoo.com/neo/groups/hercules-390/files/Madnick_for_Hercules.zip

first. Then unzip the 4K Update archive

https://groups.yahoo.com/neo/groups/hercules-390/files/Madnick_4_KB_for_Hercules.zip

into the same folder, allowing the unzip program to replace files already existing.


Contents:
---------

README_4_KB.txt  - this file
conf/madnick.cnf - Hercules configuration file
rdr/sample_operating_system_version_2.00.ipldeck - card deck to IPL sample OS
rdr/stream-3_message.card \ single cards read and printed by the demo user
rdr/stream-4_message.card / program to identify the job origin (RDR3 or RDR4)
scripts/load_card_decks - script to load card decks and get the system ready
source/sos4k.asm - updated sample OS source
sysgen/madnick_4_kb_blocks_update.xmi - XMITted PDS containing source and
                                        build information

Note that rdr/sample_operating_system_version_2.00.ipldeck is identical to
member IPLDCK4K of the PDS contained in sysgen/madnick_4_kb_blocks_update.xmi.
Follow the instructions in member $README of this PDS to rebuild the IPL deck
from source.


Usage:
------

The following steps provide minimal information to IPL the sample operating
system and to run the demo user program from four card readers simultaneously:

o make sure to have Hercules in your path
o run start_herc (*i*x systems) or start_herc.bat (Windows systems)
o enter "script scripts/load_card_decks" at the Hercules console prompt
o enter "ipl c" at the Hercules console prompt
o the system will enter a wait state (PSW=FE0200008000056A) after completion
  of the four jobs
o review the output of the four jobs in folder prt
o to rerun, start from the third bullet and use "ipl c clear" instead of "ipl c"



Have fun!

----------
31.10.2015, Juergen Winkelmann, ETH Zuerich
e-mail: winkelmann@id.ethz.ch
